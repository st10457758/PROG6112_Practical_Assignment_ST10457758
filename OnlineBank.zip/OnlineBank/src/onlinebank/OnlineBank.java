/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package onlinebank;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Sushmitha
 */
public class OnlineBank {

    static ArrayList<Account> accounts = new ArrayList<>();
    private static Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            // Display the main menu options
            System.out.println("\n--- Banking System Menu ---");
            System.out.println("1. Create Account");
            System.out.println("2. View Account Info");
            System.out.println("3. Credit Account");
            System.out.println("4. Debit Account");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");

            int option = 0;
            boolean flag = false;
            //the below try-catch makes sure the input is correct
            while (!flag) {
                try {
                    option = input.nextInt();
                    input.nextLine(); // consume the newline
                    flag = true;
                } catch (InputMismatchException e) {
                    System.out.print("Invalid input. Please enter a number: ");
                    input.nextLine(); // clear the buffer
                }
            }
            //switch case for different input
            switch (option) {
                case 1:
                    // Gather inputs for creating an account
                    System.out.print("Enter first name: ");
                    String firstName = input.nextLine();

                    System.out.print("Enter surname: ");
                    String surname = input.nextLine();

                    LocalDate dob = null;
                    while (dob == null) {
                        System.out.print("Enter date of birth (YYYY-MM-DD): ");
                        try {
                            dob = LocalDate.parse(input.nextLine());
                        } catch (Exception e) {
                            System.out.println("Invalid date format. Please enter the date in YYYY-MM-DD format.");
                        }
                    }

                    System.out.print("Enter username: ");
                    String username = input.nextLine();

                    System.out.print("Enter password: ");
                    String password = input.nextLine();

                    System.out.print("Note: Student accounts are for individuals aged 16 to 24 years.\nSelect account type (Student/Generic): ");
                    String accountType = input.nextLine();

                    // Create the account
                    createAccount(firstName, surname, dob, username, password, accountType);
                    break;

                case 2:
                    // Gather inputs for viewing account info
                    System.out.print("Enter username: ");
                    String viewUsername = input.nextLine();
                    System.out.print("Enter password: ");
                    String viewPassword = input.nextLine();

                    // View account info
                    viewAccountInfo(viewUsername, viewPassword);
                    break;

                case 3:
                    // Gather inputs for crediting an account
                    System.out.print("Enter username: ");
                    String creditUsername = input.nextLine();
                    System.out.print("Enter password: ");
                    String creditPassword = input.nextLine();
                    double creditAmount = 0;
                    flag = false;
                    while (!flag) {
                        System.out.print("Enter amount to credit: ");
                        try {
                            creditAmount = input.nextDouble();
                            input.nextLine(); // consume the newline
                            flag = true;
                        } catch (InputMismatchException e) {
                            System.out.println("Invalid input. Please enter a number.");
                            input.nextLine(); // clear the buffer
                        }
                    }
                    // Credit the account
                    creditAccount(creditUsername, creditPassword, creditAmount);
                    break;

                case 4:
                    // Gather inputs for debiting an account
                    System.out.print("Enter username: ");
                    String debitUsername = input.nextLine();
                    System.out.print("Enter password: ");
                    String debitPassword = input.nextLine();
                    double debitAmount = 0;
                    flag = false;
                    while (!flag) {
                        System.out.print("Enter amount to debit: ");
                        try {
                            debitAmount = input.nextDouble();
                            input.nextLine(); // consume the newline
                            flag = true;
                        } catch (InputMismatchException e) {
                            System.out.println("Invalid input. Please enter a number.");
                            input.nextLine(); // clear the buffer
                        }
                    }

                    // Debit the account
                    debitAccount(debitUsername, debitPassword, debitAmount);
                    break;

                case 5:
                    //for exiting the application
                    System.out.println("Thank you for using our application.");
                    return;

                default:
                    //for wrong input num
                    System.out.println("Invalid option. Please try again.");
                    break;
            }
        }
    }
    
    public static ArrayList<Account> getAccounts() {
    return accounts;
}
//Creates a new account based on the provided details.

    private static void createAccount(String firstName, String surname, LocalDate dob, String username, String password, String accountType) {
        AccountHolder holder;
        if (accountType.equalsIgnoreCase("Student")) {
            holder = new StudentAccountHolder(firstName, surname, dob, username, password);
            // Check if the holder is eligible for a student account
            if (((StudentAccountHolder) holder).isSuitable()) {
                Account newAccount = new Account(holder);
                accounts.add(newAccount);
                System.out.println("Student account created successfully with ID: " + newAccount.getAccountId());
                System.out.println("Benefits: Lower fees, financial education resources, and special offers.");
            } else {
                System.out.println("Account creation failed. Age must be between 16 and 24.");
            }
        } else if (accountType.equalsIgnoreCase("Generic")) {
            holder = new AccountHolder(firstName, surname, dob, username, password);
            Account newAccount = new Account(holder);
            accounts.add(newAccount);
            System.out.println("Generic account created successfully with ID: " + newAccount.getAccountId());
            System.out.println("Benefits: No age restrictions and standard account features.");
        } else {
            System.out.println("Invalid account type.");
        }
    }
//Displays account information for the given username and password.

    private static void viewAccountInfo(String username, String password) {
        for (Account account : accounts) {
            AccountHolder holder = account.getHolder();
            if (holder.getUsername().equals(username) && holder.getPassword().equals(password)) {
                String accountType = (holder instanceof StudentAccountHolder) ? "Student" : "Generic";
                System.out.println("\n--- Account Information ---");
                System.out.println("Account ID       : " + account.getAccountId());
                System.out.println("Name             : " + holder.getFirstName() + " " + holder.getSurname());
                System.out.println("Date of Birth    : " + holder.getDob());
                System.out.println("Account Type     : " + accountType);
                System.out.println("Balance          : $" + account.getBalance());
                System.out.println("-----------------------------");
                return;
            }
        }
        System.out.println("Account not found or incorrect credentials.");
    }

//credits money into specific account
    public static void creditAccount(String username, String password, double amount) {
        for (Account account : accounts) {
            if (account.getHolder().getUsername().equals(username) && account.getHolder().getPassword().equals(password)) {
                account.credit(amount);
                return;
            }
        }
        System.out.println("Account not found or incorrect credentials.");
    }
//debits money from a specific account

    public static void debitAccount(String username, String password, double amount) {
        for (Account account : accounts) {
            if (account.getHolder().getUsername().equals(username) && account.getHolder().getPassword().equals(password)) {
                account.debit(amount);
                return;
            }
        }
        System.out.println("Account not found or incorrect credentials.");
    }
}
