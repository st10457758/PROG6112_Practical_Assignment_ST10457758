/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package onlinebank;

/**
 *
 * @author Sushmitha
 */
import java.time.LocalDate;
//Represents a generic account holder in the bank.
public class AccountHolder {
    private String firstName;// First name of the account holder
    private String surname;// Surname of the account holder
    private LocalDate dob;// Date of birth of the account holder
    private String username;// Username for the account holder's account
    private String password;// Password for the account holder's account

    //Constructor for creating an AccountHolder.
    public AccountHolder(String firstName, String surname, LocalDate dob, String username, String password) {
        this.firstName = firstName;
        this.surname = surname;
        this.dob = dob;
        this.username = username;
        this.password = password;
    }
//getters to view the variables in this class as they are private.
    public String getFirstName() {
        return firstName;
    }

    public String getSurname() {
        return surname;
    }

    public LocalDate getDob() {
        return dob;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
}
