/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package onlinebank;

/**
 *
 * @author Sushmitha
 */
public class Account {
    private static int accountIdCounter = 1;

    private String accountId;
    private AccountHolder holder;
    private double balance;
//Constructor to create a new account.
    public Account(AccountHolder holder) {
        this.accountId = "ACC" + (accountIdCounter++);
        this.holder = holder;
        this.balance = 0.0;
    }
//getters for the private variables
    public String getAccountId() {
        return accountId;
    }

    public AccountHolder getHolder() {
        return holder;
    }

    public double getBalance() {
        return balance;
    }
//Credits the account with the specified amount.
    public void credit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Credited $" + amount);
        } else {
            System.out.println("Invalid credit amount.");
        }
    }
//Debits the account with the specified amount.
    public void debit(double amount) {
        if (amount > 0 && balance >= amount) {
            balance -= amount;
            System.out.println("Debited $" + amount);
        } else {
            System.out.println("Insufficient funds or invalid debit amount.");
        }
    }

}
