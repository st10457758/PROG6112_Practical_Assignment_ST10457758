/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package onlinebank;

/**
 *
 * @author Sushmitha
 */
import java.time.LocalDate;
//Represents a student account holder.

public class StudentAccountHolder extends AccountHolder {

    private static final int MIN_AGE = 16;// Minimum age for a student account
    private static final int MAX_AGE = 24;// Maximum age for a student account
    
//Constructor for creating a StudentAccountHolder.

    public StudentAccountHolder(String firstName, String surname, LocalDate dob, String username, String password) {
        super(firstName, surname, dob, username, password);
    }
//Checks if the account holder is eligible for a student account.
    public boolean isSuitable() {
        int age = LocalDate.now().getYear() - getDob().getYear();
        return age >= MIN_AGE && age < MAX_AGE;
    }
}
