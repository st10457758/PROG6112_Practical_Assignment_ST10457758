/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package onlinebank;

import java.time.LocalDate;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Sushmitha
 */
public class OnlineBankTest {
    
    public OnlineBankTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }



    /**
     * Test of creditAccount method, of class OnlineBank.
     */
    @Test
public void testCreditAccount() {
    
    //test to see if the correct account will be credited
    System.out.println("creditAccount");
    double creditAmount = 50;
    String username = "user1";
    String password = "pass1";
    AccountHolder holder = new AccountHolder("FirstName", "Surname", LocalDate.now(), username, password);
    Account instance = new Account(holder);
    OnlineBank.getAccounts().add(instance); // Add the account to the bank's account list
    OnlineBank.creditAccount(username, password, creditAmount);
    boolean check = instance.getBalance() == creditAmount;
    assertTrue(check);
    
// Test to see if incorrect account details are handled
System.out.println("creditAccount with incorrect details");
    double incorrectCreditAmount = 50;
    String incorrectUsername = "incorrectUser";
    String incorrectPassword = "incorrectPass";
    AccountHolder holder2 = new AccountHolder("Name", "surname", LocalDate.now(), username, password);
    Account instance2 = new Account(holder2);
    OnlineBank.getAccounts().add(instance2); // Add the second account to the bank's account list

    // Perform credit operation with incorrect details
    OnlineBank.creditAccount(incorrectUsername, incorrectPassword, incorrectCreditAmount);
    boolean checkAfterIncorrect = instance.getBalance() == creditAmount;
    assertTrue(checkAfterIncorrect);

    
    
}

    /**
     * Test of debitAccount method, of class OnlineBank.
     */
    @Test
public void testDebitAccount() {
    // Test to see if the correct account will be debited
    System.out.println("debitAccount");
    double initialBalance = 100;
    double debitAmount = 30;
    String username = "user1";
    String password = "password1";
    AccountHolder holder = new AccountHolder("FirstName", "Surname", LocalDate.now(), username, password);
    Account instance = new Account(holder);
    instance.credit(initialBalance);
    OnlineBank.getAccounts().add(instance);
    OnlineBank.debitAccount(username, password, debitAmount);
    boolean check = instance.getBalance() == (initialBalance - debitAmount);
    assertTrue(check);

    // Test to see if incorrect account details are handled properly
    System.out.println("debitAccount with incorrect details");
    double incorrectDebitAmount = 30;
    String incorrectUsername = "wrongUser";
    String incorrectPassword = "wrongPass";
    AccountHolder holder2 = new AccountHolder("FirstName", "Surname", LocalDate.now(), username, password);
    Account instance2 = new Account(holder2);
    instance2.credit(initialBalance); 
    OnlineBank.getAccounts().add(instance2); 
    OnlineBank.debitAccount(incorrectUsername, incorrectPassword, incorrectDebitAmount);
    boolean checkAfterIncorrect = instance2.getBalance() == initialBalance; 
    assertTrue(checkAfterIncorrect);
    
     // Test for amount to debit is more than the balance
    System.out.println("debitAccount with insufficient balance");
    double debitAmountInsufficient = 150;
    AccountHolder holder3 = new AccountHolder("FirstName", "Surname", LocalDate.now(), username, password);
    Account instance3 = new Account(holder3);
    instance3.credit(initialBalance);
    OnlineBank.getAccounts().add(instance3);
    OnlineBank.debitAccount(username, password, debitAmountInsufficient);
    boolean checkInsufficient = instance3.getBalance() == initialBalance;
    assertTrue(checkInsufficient);

}


    
}
