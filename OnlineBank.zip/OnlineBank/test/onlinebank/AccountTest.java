/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package onlinebank;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Sushmitha
 */
public class AccountTest {

    public AccountTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of getAccountId method, of class Account.
     */
    /**
     * Test of credit method, of class Account.
     */
    @Test
    public void testCredit() {
        //Test to see if amount is added to the balance
        System.out.println("credit");
        double amount = 10;
        AccountHolder holder = new AccountHolder(null, null, null, null, null);
        Account instance = new Account(holder);
        instance.credit(amount);
        boolean check = instance.getBalance() == 10;
        assertTrue(check);
    }

    /**
     * Test of debit method, of class Account.
     */
    @Test
    public void testDebit() {

        //Test 1 where it does debit
        System.out.println("debit");
        double initialAmount = 20;
        double debitAmount = 10;
        AccountHolder holder1 = new AccountHolder(null, null, null, null, null);
        Account instance1 = new Account(holder1);
        instance1.credit(initialAmount); // Add some initial balance
        instance1.debit(debitAmount);
        boolean check = instance1.getBalance() == (initialAmount - debitAmount);
        assertTrue(check);

        //Test 1 where it does not debit as debit is more than the balance
        System.out.println("debit");
        initialAmount = 20;
        debitAmount = 25;
        AccountHolder holder2 = new AccountHolder(null, null, null, null, null);
        Account instance2 = new Account(holder2);
        instance2.credit(initialAmount); // Add some initial balance
        instance2.debit(debitAmount);
        check = instance2.getBalance() == (initialAmount - debitAmount);
        assertFalse(check);

    }

}
