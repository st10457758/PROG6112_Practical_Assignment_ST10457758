/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package studentapp;

import java.util.ArrayList;
import java.util.Scanner;

public class StudentApp {

    /**
     *
     * @author Sushmitha
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        ArrayList<Student> studentList = new ArrayList<>();
        String choice1, choice2;// choice1 is for the main menu, choice2 for submenu
        System.out.println("STUDENT MANAGEMENT APPLICATION");
        System.out.println("**************************************");
        System.out.print("Enter (1) to launch menu or any other key to exit\nChoice: ");
        choice1 = input.nextLine();

        while (choice1.equals("1")) {
            System.out.print("Please select one of the following menu items:\n"
                    + "(1) Capture a new student.\n"
                    + "(2) Search for a student.\n"
                    + "(3) Delete a student.\n"
                    + "(4) Update a student\n"
                    + "(5) Print student report.\n"
                    + "(6) Exit Application.\n"
                    + "Choice: ");

            choice2 = input.nextLine();

            switch (choice2) {
                // Capture new student details
                case "1":
                    System.out.println("CAPTURE A NEW STUDENT\n*************************");
                    System.out.print("Enter the student id: ");
                    String ID = input.nextLine();
                    System.out.print("Enter the student name: ");
                    String name = input.nextLine();
                    System.out.print("Enter the student age: ");
                    String checkAge = input.nextLine();
                    // Validate age
                    while (!Student.StudentAge(checkAge)) {
                        System.out.println("You have entered an incorrect student age!!!"
                                + "\nPlease re-enter the student age>> ");
                        checkAge = input.nextLine();
                    }
                    int age = Integer.parseInt(checkAge);
                    System.out.print("Enter the student email: ");
                    String email = input.nextLine();
                    System.out.print("Enter the student course: ");
                    String course = input.nextLine();
                    // Create and add a new Student object to the list
                    studentList.add(Student.SaveStudent(ID, name, age, email, course));
                    System.out.println("Student details have been successfully captured.");
                    break;

                case "2":
                    // Search for a student by ID
                    System.out.print("Enter the student id to search: ");
                    ID = input.nextLine();
                    System.out.println("-----------------------------------------");
                    System.out.println(Student.SearchStudent(ID, studentList));
                    System.out.println("-----------------------------------------");
                    break;

                case "3":
                    // Delete a student by ID
                    System.out.print("Enter the student id to delete: ");
                    ID = input.nextLine();
                    boolean isDeleted = false;
                    for (int index = 0; index < studentList.size(); index++) {
                        if (studentList.get(index).ID.equals(ID)) {
                            System.out.println("Are you sure you want to student" + ID + " from the system? Yes (y) to delete");
                            String choice = input.nextLine();
                            //code attribute
                            //https://www.w3schools.com/java/ref_string_equalsignorecase.asp
                            //w3sSchools
                            //https://www.w3schools.com/
                            if (choice.equalsIgnoreCase("y")) {
                                Student.DeleteStudent(index, studentList);
                                System.out.println("Student with Student Id: " + ID + " WAS deleted!");
                                isDeleted = true;
                                break;
                            }
                        }
                    }
                    if (!isDeleted) {
                        System.out.println("Student with ID: " + ID + " was not found.");
                    }
                    break;

                case "4":
                    // Update student details by ID
                    System.out.print("Enter the student id to update: ");
                    ID = input.nextLine();
                    boolean found = false;
                    int location = -1;
                    // Find the student to update
                    for (int index = 0; index < studentList.size(); index++) {
                        if (studentList.get(index).ID.equals(ID)) {
                            location = index;
                            found = true;
                            System.out.println("Current details:\n"
                                    + "STUDENT ID: " + studentList.get(index).ID + "\nSTUDENT NAME: " + studentList.get(index).name
                                    + "\nSTUDENT AGE: " + studentList.get(index).age + "\nSTUDENT EMAIL: " + studentList.get(index).email
                                    + "\nSTUDENT COURSE: " + studentList.get(index).course);
                        }
                    }
                    if (!found) {
                        System.out.println("Student with ID " + ID + " not found.");
                        break;
                    }
                    // Update student details
                    System.out.print("What would you like to update?\n"
                            + "(1) Student name\n"
                            + "(2) Student age\n"
                            + "(3) Student email\n"
                            + "(4) Student course\n"
                            + "Your choice: ");
                    String updateChoice = input.nextLine();
                    switch (updateChoice) {
                        case "1":
                            System.out.print("Enter the new name: ");
                            String newName = input.nextLine();
                            studentList.get(location).name = newName;
                            break;
                        case "2":
                            System.out.print("Enter the new age: ");
                            String checkNewAge = input.nextLine();
                            while (!Student.StudentAge(checkNewAge)) {
                                System.out.println("You have entered an incorrect student age!!!\n"
                                        + "Please re-enter the student age: ");
                                checkNewAge = input.nextLine();
                            }
                            int newAge = Integer.parseInt(checkNewAge);
                            studentList.get(location).age = newAge;
                            break;

                        case "3":
                            System.out.print("Enter the new email: ");
                            String newEmail = input.nextLine();
                            studentList.get(location).email = newEmail;
                            break;

                        case "4":
                            System.out.print("Enter the new course: ");
                            String newCourse = input.nextLine();
                            studentList.get(location).course = newCourse;
                            break;

                        default:
                            System.out.println("Invalid choice. No changes made.");
                            break;
                    }
                    System.out.println("Student details have been updated.");
                    break;

                case "5":
                    // Print student report
                    Student.StudentReport(studentList);
                    break;

                case "6":
                    return; // Exit the program

                default:
                    System.out.println("Invalid choice. Please try again.");
            }

            System.out.print("Enter (1) to launch menu or any other key to exit\nChoice: ");
            choice1 = input.nextLine();
        }

        input.close();
    }
}

class Student {

    String ID;
    String name;
    int age;
    String email;
    String course;

    // Factory method to create and return a new Student instance
    public static Student SaveStudent(String ID, String name, int age, String email, String course) {
        Student stud = new Student();
        stud.ID = ID;
        stud.name = name;
        stud.age = age;
        stud.email = email;
        stud.course = course;
        return stud;
    }

    public static boolean StudentAge(String age) {
        //Code attribution
        //this method was adapted from stack overflow
        //https://stackoverflow.com/questions/12558206/how-can-i-check-if-a-value-is-of-type-integer
        //Ryan Amos
        //https://stackoverflow.com/users/582136/ryan-amos
        try {
            int Age = Integer.parseInt(age);
            return Age >= 16;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static String SearchStudent(String ID, ArrayList<Student> studentList) {
        for (Student stud : studentList) {
            if (stud.ID.equals(ID)) {
                return "STUDENT ID: " + stud.ID + "\nSTUDENT NAME: " + stud.name
                        + "\nSTUDENT AGE: " + stud.age + "\nSTUDENT EMAIL: " + stud.email
                        + "\nSTUDENT COURSE: " + stud.course;
            }
        }
        return "Student with Student Id: " + ID + " was not found!";
    }

    public static boolean DeleteStudent(int location, ArrayList<Student> studentList) {
        if (location >= 0 && location < studentList.size()) {
            studentList.remove(location);
            return true;
        }
        return false;
    }

    public static void StudentReport(ArrayList<Student> studentList) {
        if (studentList.isEmpty()) {
            System.out.println("No students available.");
            return;
        }
        for (int index = 0; index < studentList.size(); index++) {
            Student stud = studentList.get(index);
            System.out.println("STUDENT " + (index + 1));
            System.out.println("-----------------------------------------");
            System.out.println("STUDENT ID: " + stud.ID + "\nSTUDENT NAME: " + stud.name
                    + "\nSTUDENT AGE: " + stud.age + "\nSTUDENT EMAIL: " + stud.email
                    + "\nSTUDENT COURSE: " + stud.course);
            System.out.println("-----------------------------------------");
        }
    }
}
