/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package studentapp;

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Sushmitha
 */
public class StudentTest {
    
    public StudentTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of SaveStudent method, of class Student.
     */
    @Test
    public void testSaveStudent() {
        System.out.println("SaveStudent");
        String ID = "001";
        String name = "Adrian Black";
        int age = 19;
        String email = "adrianb@gmail.com";
        String course = "BCAD";
        Student expResult = new Student();
        expResult.ID = ID;
        expResult.name = name;
        expResult.age = age;
        expResult.email = email;
        expResult.course = course;
        Student result = Student.SaveStudent(ID, name, age, email, course);
        assertEquals(expResult.ID, result.ID);
        assertEquals(expResult.name, result.name);
        assertEquals(expResult.age, result.age);
        assertEquals(expResult.email, result.email);
        assertEquals(expResult.course, result.course);
    }

    /**
     * Test of StudentAge method, of class Student.
     */
    @Test
    public void testStudentAge() {
        //Test 1 for valid student age
        System.out.println("StudentAge");
        String age = "16";
        assertTrue(Student.StudentAge(age));
        
        
        //Test 2 for invalid student age
        age = "15";
        assertFalse(Student.StudentAge(age));
        
        
        //Test 3 for invalid char
        age = "c";
        assertFalse(Student.StudentAge(age));
        
    }

    /**
     * Test of SearchStudent method, of class Student.
     */
    @Test
    public void testSearchStudent() {
        //Test 1 for TestSearchStudent where student is found
        System.out.println("SearchStudent");
        ArrayList<Student> studentList = new ArrayList<>();
        Student testStudent = new Student();
        testStudent.ID = "001";
        testStudent.name = "Adrian Black";
        testStudent.age = 19;
        testStudent.email = "adrianb@gmail.com";
        testStudent.course = "BCAD";
        studentList.add(testStudent);
        String expResult = "STUDENT ID: 001";
        String result = Student.SearchStudent("001", studentList);
        assertTrue(result.contains(expResult));

        //Test 2 for TestSearchStudent where student is not found
        expResult = "not found!";
        result = Student.SearchStudent("002", studentList);
        assertTrue(result.contains(expResult));

    }

    /**
     * Test of DeleteStudent method, of class Student.
     */
    @Test
    public void testDeleteStudent() {
        //Test 1 for TestSDeleteStudent where student is found and deleted.
        System.out.println("DeleteStudent");
        ArrayList<Student> studentList = new ArrayList<>();
        Student testStudent = new Student();
        testStudent.ID = "001";
        testStudent.name = "Adrian Black";
        testStudent.age = 19;
        testStudent.email = "adrianb@gmail.com";
        testStudent.course = "BCAD";
        studentList.add(testStudent);
        boolean result = Student.DeleteStudent(0, studentList);
        assertTrue(result);
        
        
        //Test 2 for TestSDeleteStudent where student is not found as the arraylist is empty.
        result = Student.DeleteStudent(0, studentList);
        assertFalse(result);
    }

}
